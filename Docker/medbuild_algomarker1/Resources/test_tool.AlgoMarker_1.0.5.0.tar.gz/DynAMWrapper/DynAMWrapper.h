#ifndef __SODYNWRAPPER_H
#define __SODYNWRAPPER_H

#include "AlgoMarkerFlat.h"

void load_am(const char * am_fname);

#endif //__SODYNWRAPPER_H
