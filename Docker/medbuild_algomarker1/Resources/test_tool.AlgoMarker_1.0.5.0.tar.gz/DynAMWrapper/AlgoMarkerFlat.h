#ifndef __ALGOMARKER_FLAT_H
#define __ALGOMARKER_FLAT_H

#include <vector>

#define ALGOMARKER_FLAT_API

typedef void AlgoMarker;
typedef void AMRequest;
typedef void AMResponse;
typedef void AMResponses;
#include "../AlgoMarker/AlgoMarker.h"

#endif // __ALGOMARKER_FLAT_H
